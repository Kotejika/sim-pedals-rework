/*
 * Minimal ADS1220 driver for a 4-wire load cell (NA151 etc.).
 *   AIN0/AIN1 = bridge output, E+ -> AVDD (3.3 V), E- -> GND, reference = AVDD (ratiometric)
 *   gain 128, PGA on, normal mode 1000 SPS, continuous conversion.
 * SPI mode 1 (CPOL=0, CPHA=1), MSB first, bit-banged on GPIO.
 */
#include <zephyr/kernel.h>
#include <zephyr/drivers/gpio.h>
#include "ads1220.h"

#define CMD_RESET  0x06
#define CMD_START  0x08
#define CMD_PWRDWN 0x02
#define CMD_RREG(r, n) (0x20 | ((r) << 2) | ((n) - 1))
#define CMD_WREG(r, n) (0x40 | ((r) << 2) | ((n) - 1))

/* REG0: MUX=0000 (AIN0-AIN1), GAIN=111 (128), PGA_BYPASS=0 */
#define REG0_VAL 0x0E
/* REG1: DR=110 (1000 SPS normal), MODE=00 normal, CM=1 continuous, TS=0, BCS=0 */
#define REG1_VAL 0xC4
/* REG2: VREF=11 (AVDD as reference), 50/60=00, PSW=0, IDAC=000 */
#define REG2_VAL 0xC0
/* REG3: no IDAC routing, DRDYM=0 */
#define REG3_VAL 0x00

/* SPI mode 1 (CPOL=0, CPHA=1): SCLK idles low; DOUT changes on the rising edge, DIN is latched on the falling edge.
 * Master drives DIN while SCLK is high and reads DOUT just before the falling edge. ~2 us per bit, far below
 * the ADS1220 limit (SCLK <= 4 MHz); the 3-byte read is ~70 us. */
#define HALF_US 1

static uint8_t sw_byte(struct ads1220 *a, uint8_t out)
{
	uint8_t in = 0;

	for (int i = 7; i >= 0; i--) {
		gpio_pin_set_dt(&a->sck, 1);
		gpio_pin_set_dt(&a->mosi, (out >> i) & 1);
		k_busy_wait(HALF_US);
		in = (in << 1) | (gpio_pin_get_dt(&a->miso) > 0 ? 1 : 0);
		gpio_pin_set_dt(&a->sck, 0);
		k_busy_wait(HALF_US);
	}
	k_busy_wait(2);                /* >= 4 tCLK between bytes of one command */
	return in;
}

static int xfer(struct ads1220 *a, const uint8_t *tx, uint8_t *rx, size_t n)
{
	gpio_pin_set_dt(&a->cs, 1);
	k_busy_wait(2);
	for (size_t i = 0; i < n; i++) {
		uint8_t r = sw_byte(a, tx[i]);

		if (rx) {
			rx[i] = r;
		}
	}
	gpio_pin_set_dt(&a->mosi, 0);
	gpio_pin_set_dt(&a->cs, 0);
	k_busy_wait(2);
	return 0;
}

struct ads_diag ads_diag;

int ads1220_init(struct ads1220 *a)
{
	uint8_t cmd;
	uint8_t w[5] = {CMD_WREG(0, 4), REG0_VAL, REG1_VAL, REG2_VAL, REG3_VAL};
	uint8_t rd[5] = {CMD_RREG(0, 4), 0, 0, 0, 0}, back[5] = {0};

	ads_diag.tries++;
	if (!gpio_is_ready_dt(&a->cs) || !gpio_is_ready_dt(&a->sck) ||
	    !gpio_is_ready_dt(&a->mosi) || !gpio_is_ready_dt(&a->miso)) {
		ads_diag.err = ADS_ERR_DEV;
		return -ENODEV;
	}
	gpio_pin_configure_dt(&a->cs, GPIO_OUTPUT_INACTIVE);
	gpio_pin_configure_dt(&a->sck, GPIO_OUTPUT_INACTIVE);
	gpio_pin_configure_dt(&a->mosi, GPIO_OUTPUT_INACTIVE);
	gpio_pin_configure_dt(&a->miso, GPIO_INPUT);
	k_msleep(5);           /* power-up: wait > 50 us + 2^14 fclk */

	cmd = CMD_RESET;
	if (xfer(a, &cmd, NULL, 1)) {
		ads_diag.err = ADS_ERR_SPI;
		return -EIO;
	}
	k_msleep(2);

	if (xfer(a, w, NULL, 5) || xfer(a, rd, back, 5)) {
		ads_diag.err = ADS_ERR_SPI;
		return -EIO;
	}
	for (int i = 0; i < 4; i++) {
		ads_diag.regs[i] = back[i + 1];
	}
	if (back[1] != REG0_VAL || back[2] != REG1_VAL || back[3] != REG2_VAL ||
	    back[4] != REG3_VAL) {
		ads_diag.err = ADS_ERR_REGS;   /* chip not answering / wiring wrong */
		return -EIO;
	}
	cmd = CMD_START;
	if (xfer(a, &cmd, NULL, 1)) {
		ads_diag.err = ADS_ERR_SPI;
		return -EIO;
	}
	ads_diag.err = ADS_OK;
	return 0;
}

int ads1220_read(struct ads1220 *a, int32_t *out)
{
	uint8_t tx[3] = {0, 0, 0}, rx[3];
	int ret = xfer(a, tx, rx, 3);   /* direct read: clock out data while DRDY is low */

	if (ret) {
		return ret;
	}
	int32_t v = ((int32_t)rx[0] << 16) | ((int32_t)rx[1] << 8) | rx[2];
	if (v & 0x800000) {
		v -= 0x1000000;
	}
	*out = v;
	return 0;
}

void ads1220_powerdown(struct ads1220 *a)
{
	uint8_t cmd = CMD_PWRDWN;
	xfer(a, &cmd, NULL, 1);
}
